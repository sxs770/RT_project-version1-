import numpy as np
import pandas as pd
from tensorflow import keras
import tensorflow as tf
import random
import os

from keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

def Seed_Fixed(seed):
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    tf.random.set_seed(seed)

My_Seed = 777
Seed_Fixed(My_Seed)

def train_data(split_train_path, split_val_path):
    data_generator = ImageDataGenerator(rescale = 1/255)

    train_generator = data_generator.flow_from_directory(split_train_path, target_size = (224, 224), color_mode = 'grayscale', class_mode = 'binary', batch_size = 1)
    n_img = train_generator.n
    steps = n_img//1

    imgs, labels = [], []

    for i in range(steps):
        a, b = train_generator.next()
        imgs.extend(a)
        labels.extend(b)

        X_train = np.asarray(imgs)
        y_train = np.asarray(labels)

    val_generator = data_generator.flow_from_directory(split_val_path, target_size = (224, 224), color_mode = 'grayscale', class_mode = 'binary', batch_size = 1)
    n_img = val_generator.n
    steps = n_img//1

    imgs, labels = [], []

    for i in range(steps):
        a, b = val_generator.next()
        imgs.extend(a)
        labels.extend(b)

        X_val = np.asarray(imgs)
        y_val = np.asarray(labels)
    
    return X_train, X_val, y_train, y_val

def test_data(train_path):
    data_generator = ImageDataGenerator(rescale = 1/255)

    train_generator = data_generator.flow_from_directory(train_path,
                                                         target_size = (224, 224),
                                                         color_mode = 'grayscale',
                                                         class_mode = 'binary',
                                                         batch_size = 1
                                                        )
    n_img = train_generator.n
    steps = n_img // 1

    imgs, labels = [], []

    for i in range(steps):
        a, b = train_generator.next()
        imgs.extend(a)
        labels.extend(b)

        X_train = np.asarray(imgs)
        y_train = np.asarray(labels)
    
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size = 0.1, random_state = My_Seed, stratify = y_train)
    
    return X_train, X_val, y_train, y_val