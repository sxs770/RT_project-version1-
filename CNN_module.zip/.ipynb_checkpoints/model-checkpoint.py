import numpy as np
import pandas as pd
from tensorflow import keras
import cv2
import tensorflow as tf
import random
import os

from tensorflow.keras.applications import EfficientNetB0, ResNet50, VGG16
from tensorflow.keras.layers import Input, Dense, Conv2D, MaxPooling2D, Flatten, GlobalAveragePooling2D
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import ModelCheckpoint, EarlyStopping
from sklearn.metrics import precision_score, recall_score, f1_score, accuracy_score
from CNN_module.preprocessing import train_data

def training_model(model_name, learning_rate, batch_size, training_epochs, X_train, X_val, y_train, y_val):
    
    
    
    if model_name == 'CNN':
        model = tf.keras.models.Sequential([
            tf.keras.layers.Conv2D(16, (3, 3), activation='relu', input_shape=(224, 224, 1)),
            tf.keras.layers.MaxPool2D(2, 2),
            tf.keras.layers.Conv2D(32, (3, 3), activation='relu'),
            tf.keras.layers.MaxPool2D(2, 2),
            tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
            tf.keras.layers.MaxPool2D(2, 2),
            tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
            tf.keras.layers.MaxPool2D(2, 2),
            tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
            tf.keras.layers.MaxPool2D(2, 2),
            tf.keras.layers.Flatten(),
            tf.keras.layers.Dense(512, activation='relu'),
            tf.keras.layers.Dense(1, activation='sigmoid')
        ])
    
    elif model_name == 'VGG16':
        input_tensor = Input(shape=(224, 224, 1))
        model = VGG16(weights = None, include_top = False, input_tensor = input_tensor)
        
        layer_dict = dict([(layer.name, layer) for layer in model.layers])
        
        x = layer_dict['block5_pool'].output
        x = tf.keras.layers.Flatten()(x)
        x = tf.keras.layers.Dense(4096, activation = 'relu')(x)
        x = tf.keras.layers.Dense(4096, activation = 'relu')(x)
        x = tf.keras.layers.Dense(1, activation = 'sigmoid')(x)

        model = Model(inputs = model.input, outputs = x)
    
    elif model_name == 'ResNet50':
        input_tensor = Input(shape=(224, 224, 1))
        model = ResNet50(weights = None, include_top = False, input_tensor = input_tensor)
        
        layer_dict = dict([(layer.name, layer) for layer in model.layers])
        
        x = layer_dict['conv5_block3_out'].output
        x = tf.keras.layers.GlobalAveragePooling2D()(x)
        x = tf.keras.layers.Dense(1, activation = 'sigmoid')(x)

        model = Model(inputs = model.input, outputs = x)
        
    elif model_name == 'EfficientNet-B0':
        input_tensor = Input(shape=(224, 224, 1))
        model = EfficientNetB0(weights = None, include_top = False, input_tensor = input_tensor)
        
        layer_dict = dict([(layer.name, layer) for layer in model.layers])
        
        x = layer_dict['top_activation'].output
        x = tf.keras.layers.GlobalAveragePooling2D()(x)
        x = tf.keras.layers.Dense(1, activation = 'sigmoid')(x)

        model = Model(inputs = model.input, outputs = x)
    
    filename = ('train_model/' + model_name + '.h5')
    checkpoint = ModelCheckpoint(filename,
                                 monitor = 'val_binary_accuracy',
                                 verbose = 1,
                                 save_best_only = True,
                                 mode = 'auto')

    earlystopping = EarlyStopping(monitor = 'val_binary_accuracy', 
                                  patience = 30,
                                 )

    model.compile(
        optimizer = tf.keras.optimizers.Adam(learning_rate = learning_rate),
        loss = tf.keras.losses.BinaryCrossentropy(),
        metrics = tf.keras.metrics.BinaryAccuracy())
    
    model.fit(X_train, y_train,
              validation_data = (X_val, y_val),
              epochs = training_epochs,
              batch_size = batch_size,
              callbacks = [checkpoint ,earlystopping])
    
def test_model(model_file):
    model = tf.keras.models.load_model(model_file)
    
    Reject_Test_Data_Path = '03_Test Data_2694(Accept 2364_Reject 33)/0_Reject'
    Accept_Test_Data_Path = '03_Test Data_2694(Accept 2364_Reject 33)/1_Accept'

    file_name = []
    y_pred = []
    y_test = []

    for filename in os.listdir(Reject_Test_Data_Path):
        img = cv2.imread(os.path.join(Reject_Test_Data_Path, filename), cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, dsize = (224, 224), interpolation = cv2.INTER_CUBIC)
        img = img/255
        img = img.reshape(-1, 224, 224, 1)
        model.predict(img)
    
        if model.predict(img) < 0.5:
            y_pred.append(np.array([0]))
        else:
            y_pred.append(np.array([1]))
    
        y_test.append(np.array([0]))
        file_name.append(filename)

    for filename in os.listdir(Accept_Test_Data_Path):
        img = cv2.imread(os.path.join(Accept_Test_Data_Path, filename), cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, dsize = (224, 224), interpolation = cv2.INTER_CUBIC)
        img = img/255
        img = img.reshape(-1, 224, 224, 1)
        model.predict(img)
    
        if model.predict(img) < 0.5:
            y_pred.append(np.array([0]))
        else:
            y_pred.append(np.array([1]))
    
        y_test.append(np.array([1]))
        file_name.append(filename)
        
    return file_name, y_pred, y_test
    