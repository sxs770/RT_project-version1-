import numpy as np
import pandas as pd
from tensorflow import keras
import tensorflow as tf
import random
import os

from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

def Seed_Fixed(seed):
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    tf.random.set_seed(seed)

My_Seed = 777
Seed_Fixed(My_Seed)

def train_data(train_path, batch_size):
    data_generator = ImageDataGenerator(rescale = 1/255)

    train_generator = data_generator.flow_from_directory(train_path,
                                                         target_size = (224, 224),
                                                         color_mode = 'grayscale',
                                                         class_mode = 'binary'
                                                        )
    n_img = train_generator.n
    steps = n_img // batch_size

    imgs, labels = [], []

    for i in range(steps):
        a, b = train_generator.next()
        imgs.extend(a)
        labels.extend(b)

        X_train = np.asarray(imgs)
        y_train = np.asarray(labels)
        
    X_train, X_test, y_train, y_test = train_test_split(X_train, y_train, test_size = 0.2, random_state = My_Seed)
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size = 0.2, random_state = My_Seed)
    
    return X_train, X_val, X_test, y_train, y_test, y_val

def test_data(train_path, batch_size):
    data_generator = ImageDataGenerator(rescale = 1/255)

    train_generator = data_generator.flow_from_directory(train_path,
                                                         target_size = (224, 224),
                                                         color_mode = 'grayscale',
                                                         class_mode = 'binary'
                                                        )
    n_img = train_generator.n
    steps = n_img // batch_size

    imgs, labels = [], []

    for i in range(steps):
        a, b = train_generator.next()
        imgs.extend(a)
        labels.extend(b)

        X_train = np.asarray(imgs)
        y_train = np.asarray(labels)
    
    X_train, X_val, y_train, y_val = train_test_split(X_train, y_train, test_size = 0.2, random_state = My_Seed)
    
    return X_train, X_val, y_train, y_val